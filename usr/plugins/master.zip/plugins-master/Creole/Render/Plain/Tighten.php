<?php
class Text_Wiki_Render_Plain_Tighten extends Text_Wiki_Render {
    
    
    function token()
    {
        return '';
    }
}
?>